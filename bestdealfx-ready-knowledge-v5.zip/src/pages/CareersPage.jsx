import React, { useState } from "react";

const H = ({children, style}) => (
  <h3 style={{fontSize:18,fontWeight:700,margin:'6px 0 10px', ...style}}>{children}</h3>
);

const Card = ({children, style}) => (
  <div className="card" style={{padding:18, ...style}}>{children}</div>
);

export default function CareersPage(){
  const highlights = [
    {icon:"🌍", title:"Global Exposure", text:"Work across international remittances and forex operations."},
    {icon:"📈", title:"Career Growth", text:"Structured training and clear growth paths."},
    {icon:"💼", title:"Professional Development", text:"Hands-on learning of RBI/FEMA compliance and CRM."},
    {icon:"🤝", title:"Inclusive Culture", text:"Transparent, ethical, and supportive work environment."},
  ];

  const jobs = [
    {
      title: "Customer Relationship Executive",
      location: "Hyderabad",
      type: "Full-time",
      summary: "Front-office role handling walk-in customers, queries, and documentation.",
      responsibilities: [
        "Assist customers with forex/remittance products",
        "Generate quotes & invoices; maintain records",
        "Coordinate KYC and required compliance documents",
      ],
      requirements: [
        "0–2 years experience (freshers welcome)",
        "Good communication skills & MS Office basics",
        "Graduate in any stream; finance preferred",
      ]
    },
    {
      title: "Forex Operations Officer",
      location: "Hyderabad",
      type: "Full-time",
      summary: "Back-office operations for cash/TT/FC cards with accuracy and speed.",
      responsibilities: [
        "Process buy/sell, encashment & travel card reloads",
        "Handle settlements, invoicing and daily recon",
        "Adhere to RBI/FEMA and internal SOPs",
      ],
      requirements: [
        "1–3 years in forex ops preferred",
        "Detail oriented; comfortable with numbers",
        "Knowledge of RBI KYC Master Direction is a plus",
      ]
    },
    {
      title: "Compliance & KYC Specialist",
      location: "Hybrid/Remote",
      type: "Full-time",
      summary: "Review transactions, screen sanctions lists, maintain records & MIS.",
      responsibilities: [
        "Daily sanctions-list screening and escalations",
        "CDD review for purpose codes & documentation",
        "Support audits and regulatory reporting",
      ],
      requirements: [
        "2+ years in compliance/KYC/AML",
        "Strong understanding of FEMA & RBI guidelines",
        "Excellent documentation & follow-up skills",
      ]
    },
  ];

  const [openJob, setOpenJob] = useState(null);

  return (
    <section className="container">
      {/* Hero */}
      <div style={{display:'grid', gap:12, margin:'0 0 16px'}}>
        <h2>Careers</h2>
        <p className="small" style={{color:'#475569'}}>
          Join Best Deal Forex — a trusted brand in foreign exchange and travel services.
          We value passion, integrity, and a customer-first mindset.
        </p>
      </div>

      {/* Highlights */}
      <div className="grid grid-4" style={{gap:16, marginBottom:16}}>
        {highlights.map((h, i) => (
          <Card key={i}>
            <div style={{display:'flex', alignItems:'center', gap:8}}>
              <span style={{fontSize:22}}>{h.icon}</span>
              <strong>{h.title}</strong>
            </div>
            <p className="small" style={{marginTop:8, color:'#475569'}}>{h.text}</p>
          </Card>
        ))}
      </div>

      {/* Open Positions */}
      <Card style={{marginBottom:16}}>
        <H>Open Positions</H>
        <div style={{display:'grid', gap:12}}>
          {jobs.map((job, idx) => (
            <div key={idx} className="card" style={{padding:14}}>
              <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', gap:10, flexWrap:'wrap'}}>
                <div>
                  <div style={{fontWeight:700}}>{job.title}</div>
                  <div className="small" style={{color:'#64748b'}}>{job.location} • {job.type}</div>
                </div>
                <button className="btn" onClick={()=>setOpenJob(openJob===idx?null:idx)}>
                  {openJob===idx ? "Hide Details" : "View Details"}
                </button>
              </div>

              <p className="small" style={{marginTop:8}}>{job.summary}</p>

              {openJob===idx && (
                <div style={{display:'grid', gap:8, marginTop:10}}>
                  <div>
                    <strong>Responsibilities</strong>
                    <ul className="small" style={{margin:'6px 0 0 18px'}}>
                      {job.responsibilities.map((r, i)=>(<li key={i} style={{marginBottom:4}}>{r}</li>))}
                    </ul>
                  </div>
                  <div>
                    <strong>Requirements</strong>
                    <ul className="small" style={{margin:'6px 0 0 18px'}}>
                      {job.requirements.map((r, i)=>(<li key={i} style={{marginBottom:4}}>{r}</li>))}
                    </ul>
                  </div>
                  <div style={{marginTop:8}}>
                    <a className="btn" href="mailto:careers@bestdealfx.com?subject=Application%20for%20%BDFX%20Role">Apply via Email</a>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </Card>

      {/* Life at BDFX */}
      <Card style={{marginBottom:16}}>
        <H>Life at BDFX</H>
        <p className="small" style={{color:'#475569'}}>
          We invest in learning and recognition. Expect onboarding, mentorship, and
          regular trainings on RBI compliance and forex operations.
        </p>
      </Card>

      {/* Apply Section */}
      <Card>
        <H>How to Apply</H>
        <p className="small" style={{color:'#475569'}}>
          Send your resume to <a href="mailto:careers@bestdealfx.com">careers@bestdealfx.com</a> or fill the quick form below.
        </p>
        <form onSubmit={(e)=>e.preventDefault()} style={{display:'grid', gap:10, maxWidth:560}}>
          <input className="input" placeholder="Full Name" required/>
          <input className="input" type="email" placeholder="Email" required/>
          <input className="input" placeholder="Phone"/>
          <textarea className="input" rows="4" placeholder="Short note / role applying for"></textarea>
          <button className="btn" type="submit">Submit</button>
        </form>
      </Card>
    </section>
  );
}