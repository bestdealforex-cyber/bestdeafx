import React from "react";

const sections = [
  {
    title: "RBI Guidelines on International Money Transfer",
    points: [
      "Remittances only through RBI‑authorised channels (AD‑I banks, AD‑II, FFMCs).",
      "Permitted purposes: education, medical, travel, family maintenance, gifts, business expenses.",
      "LRS limit: up to USD 250,000 per financial year per individual.",
      "Cash abroad: typically up to USD 3,000 per trip; balance via forex cards or traveller’s cheques.",
      "Documents: PAN, passport, Form A2, invoices/fee receipts as applicable.",
      "Prohibited remittances: lottery, margin trading, speculative or banned investments."
    ]
  },
  {
    title: "RBI Guidelines for Foreign Exchange Transactions",
    points: [
      "Only Authorised Dealers (ADs) can transact in forex under FEMA/RBI.",
      "Personal travel: forex entitlement within RBI limits.",
      "Business travel: higher entitlements possible with documentation.",
      "Surrender unused forex within prescribed time after return (except coins).",
      "Residents may retain up to USD 2,000 equivalent for future use.",
      "Mandatory compliance: purpose codes must be correct; KYC required."
    ]
  },
  {
    title: "Travel Packing Checklist",
    points: [
      "Carry documents: passport, visa, tickets, forex card/cash, travel insurance.",
      "Pack weather‑appropriate clothing; include formals for interviews or business.",
      "Take essentials: medicines & prescriptions, chargers, universal adaptor, toiletries, first‑aid kit.",
      "Tips: keep photocopies/digital copies of documents, pack light, share itinerary with family."
    ]
  },
  {
    title: "Forex Application & Declaration Form",
    points: [
      "Purpose: compliance form required for every forex purchase/remittance.",
      "Information needed: applicant details, PAN, passport, forex amount, purpose, beneficiary.",
      "Declaration: applicant certifies compliance with FEMA/RBI rules and permitted purpose.",
      "KYC documents: PAN, ID proof, address proof, invoices/fee letters where relevant."
    ]
  }
];

export default function KnowledgeCenterPage(){
  return (
    <section className="container">
      <h2>Knowledge Centre</h2>
      <p className="small" style={{color:'#475569'}}>
        Summaries of key RBI guidelines and practical resources. Always cross‑check the official RBI website and circulars for updates.
      </p>

      <div className="grid grid-2" style={{gap:16}}>
        {sections.map((s, idx)=>(
          <div key={idx} className="card" style={{padding:16}}>
            <div style={{fontWeight:700, marginBottom:6}}>{s.title}</div>
            <ul className="small" style={{margin:'6px 0 0 18px', color:'#334155'}}>
              {s.points.map((p, i)=>(<li key={i} style={{marginBottom:6}}>{p}</li>))}
            </ul>
          </div>
        ))}
      </div>

      <div className="card" style={{padding:16, marginTop:16, background:'#eef6ff'}}>
        <div className="small">
          <strong>Note:</strong> This content is summarised from PDF resources and RBI FAQs. For the latest updates, please visit:&nbsp;
          <a href="https://www.rbi.org.in/commonman/english/scripts/FAQs.aspx?Id=829" target="_blank" rel="noreferrer">
            RBI Official FAQs
          </a>.
        </div>
      </div>
    </section>
  );
}