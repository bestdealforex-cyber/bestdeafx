import React, { useState } from "react";

/**
 * CareersPage
 * - Edit the jobs array below to add/update openings.
 * - Replace the images in the gallery with your own URLs (or remove the section).
 */
const jobsData = [
  {
    id: "cre",
    title: "Customer Relationship Executive",
    location: "Hyderabad (On-site)",
    type: "Full-time",
    summary:
      "Front-office role handling walk-ins and phone inquiries, quotations, and basic documentation.",
    responsibilities: [
      "Assist customers with forex & travel products",
      "Generate quotes and invoices, maintain records",
      "Coordinate with operations & compliance teams",
    ],
    requirements: [
      "0–3 years experience (freshers welcome)",
      "Good communication skills",
      "Basic Excel & email etiquette",
    ],
  },
  {
    id: "fxo",
    title: "Forex Operations Officer",
    location: "Hyderabad (On-site)",
    type: "Full-time",
    summary:
      "Back-office operations including cash currency, travel cards, and documentation.",
    responsibilities: [
      "Process forex transactions with 100% accuracy",
      "Handle card loads, encashments & KYC checks",
      "Support branch reconciliation & reporting",
    ],
    requirements: [
      "1–4 years in forex/fin-services preferred",
      "Working knowledge of KYC / RBI-FEMA guidelines",
      "Detail oriented with strong ownership",
    ],
  },
  {
    id: "cokyc",
    title: "Compliance & KYC Specialist",
    location: "Hybrid / Remote",
    type: "Full-time / Contract",
    summary:
      "Ensure compliance with RBI KYC and FEMA guidelines. Monitor transactions and maintain records.",
    responsibilities: [
      "Daily sanction screening & CDD review",
      "Audit support and policy documentation",
      "Training for branches on process updates",
    ],
    requirements: [
      "2–6 years compliance experience",
      "Strong documentation & stakeholder skills",
      "Up-to-date with RBI-KYC directions",
    ],
  },
];

const gallery = [
  "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=800&q=60",
  "https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=800&q=60",
  "https://images.unsplash.com/photo-1529336953121-ad5a00adcd16?auto=format&fit=crop&w=800&q=60",
];

export default function CareersPage() {
  const [openId, setOpenId] = useState(null);

  return (
    <section className="container">
      {/* Hero */}
      <div className="card" style={{padding: 20, marginBottom: 20}}>
        <h2 style={{marginBottom: 6}}>Careers</h2>
        <p className="small">
          Join <strong>Best Deal Forex (BDFX)</strong>—a trusted brand in foreign exchange and travel services.
          We value passion, integrity, and a customer‑first mindset.
        </p>
      </div>

      {/* Why Work With Us */}
      <div className="grid grid-3" style={{marginBottom: 20}}>
        <div className="card">
          <div style={{fontWeight:600, marginBottom:6}}>🌍 Global Exposure</div>
          <p className="small">Work with international customers and cross-border services.</p>
        </div>
        <div className="card">
          <div style={{fontWeight:600, marginBottom:6}}>📈 Career Growth</div>
          <p className="small">Structured training and clear growth paths for performers.</p>
        </div>
        <div className="card">
          <div style={{fontWeight:600, marginBottom:6}}>🤝 Inclusive Culture</div>
          <p className="small">Transparent, ethical, supportive team environment.</p>
        </div>
      </div>

      {/* Open Positions */}
      <h3 style={{margin:'10px 0'}}>Open Positions</h3>
      <div className="grid grid-2">
        {jobsData.map(job => (
          <div key={job.id} className="card" style={{padding:18}}>
            <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', gap:12}}>
              <div>
                <div style={{fontWeight:700}}>{job.title}</div>
                <div className="small" style={{color:'#475569'}}>{job.location} • {job.type}</div>
              </div>
              <button className="btn" onClick={()=>setOpenId(openId===job.id?null:job.id)}>
                {openId === job.id ? "Hide Details" : "View Details"}
              </button>
            </div>
            <p className="small" style={{marginTop:8}}>{job.summary}</p>

            {openId === job.id && (
              <div style={{marginTop:8}}>
                <div style={{fontWeight:600}}>Responsibilities</div>
                <ul className="small" style={{marginLeft:18}}>
                  {job.responsibilities.map((r, i)=>(<li key={i} style={{marginBottom:4}}>{r}</li>))}
                </ul>
                <div style={{fontWeight:600, marginTop:8}}>Requirements</div>
                <ul className="small" style={{marginLeft:18}}>
                  {job.requirements.map((r, i)=>(<li key={i} style={{marginBottom:4}}>{r}</li>))}
                </ul>
                <a className="btn secondary" href="mailto:careers@bestdealfx.com?subject=Application%20-%20BDFX" style={{marginTop:10}}>Apply via Email</a>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Life at BDFX */}
      <h3 style={{margin:'18px 0 10px'}}>Life at BDFX</h3>
      <div className="grid grid-3">
        {gallery.map((src, i)=> (
          <div key={i} className="card" style={{overflow:'hidden', padding:0}}>
            <img src={src} alt="Life at BDFX" style={{width:'100%', height:180, objectFit:'cover'}}/>
          </div>
        ))}
      </div>

      {/* How to Apply */}
      <div className="card" style={{padding:18, marginTop:20}}>
        <h3>How to Apply</h3>
        <p className="small">Send your resume to <a href="mailto:careers@bestdealfx.com">careers@bestdealfx.com</a> or use the form below.</p>
        <form onSubmit={(e)=>{e.preventDefault(); alert('Thanks! We will get back to you.')}}>
          <div style={{display:'grid', gap:10, gridTemplateColumns:'1fr 1fr'}}>
            <input className="input" placeholder="Full Name" required/>
            <input className="input" type="email" placeholder="Email" required/>
          </div>
          <textarea className="input" placeholder="Short note (optional)" rows={4} style={{marginTop:10}}/>
          <div style={{display:'flex', gap:10, marginTop:10}}>
            <input className="input" type="file" accept=".pdf,.doc,.docx"/>
            <button className="btn" type="submit">Submit</button>
          </div>
        </form>
      </div>
    </section>
  );
}
