
import React, { useState } from 'react'
import { Routes, Route, NavLink, Link } from 'react-router-dom'
import CareersPage from './pages/CareersPage'
import KnowledgeCenterPage from './pages/KnowledgeCenterPage'
import { Phone, Mail, MessageCircle, Home as HomeIcon, Boxes, Newspaper, BookOpen, Route as RouteIcon, Globe2, CreditCard, Send, CheckCircle2, Shield, Clock, IndianRupee } from 'lucide-react'

const CONTACT_PHONE = "+91 96763 21959";
const CONTACT_TEL = "+919676321959";
const CONTACT_EMAIL = "info@bestdealfx.com";
const CONTACT_WHATSAPP = "919676321959";

export default function App(){
  return (
    <div className="page">
      
      
      <div className="header-wrap">
        <header className="container header" style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'12px 10px'}}>
          {/* Left: Logo */}
          <Link to="/" className="brand" style={{display:'flex',alignItems:'center',gap:10,textDecoration:'none'}}>
            <img src="/logo.png" alt="Logo" style={{height:52}}/>
          </Link>

          {/* Center: Nav */}
          <nav className="navbar" style={{display:'flex',gap:42,justifyContent:'center',alignItems:'center',textTransform:'uppercase',fontWeight:800,letterSpacing:1}}>
            <NavLink to="/" end className={({isActive})=>'nav-item' + (isActive?' active':'')}>Home</NavLink>
            <NavLink to="/about" className={({isActive})=>'nav-item' + (isActive?' active':'')}>About Us</NavLink>
            <NavLink to="/services" className={({isActive})=>'nav-item' + (isActive?' active':'')}>Services</NavLink>
            <NavLink to="/gallery" className={({isActive})=>'nav-item' + (isActive?' active':'')}>Gallery</NavLink>
            <NavLink to="/careers" className={({isActive})=>'nav-item' + (isActive?' active':'')}>Careers</NavLink>
            <NavLink to="/knowledge" className={({isActive})=>'nav-item' + (isActive?' active':'')}>Knowledge Centre</NavLink>
            <NavLink to="/contact" className={({isActive})=>'nav-item' + (isActive?' active':'')}>Contact</NavLink>
          </nav>
        </header>
        {/* bottom rule */}
        <div style={{height:3,background:'#111',width:'100%'}}></div>
      </div>



      <main className="main">
        <Routes>
          <Route path="/" element={<HomePage/>}/>
          <Route path="/services" element={<ServicesPage/>}/>
          <Route path="/products" element={<ProductsPage/>}/>
          <Route path="/blog" element={<BlogPage/>}/>
          <Route path="/knowledge" element={<KnowledgeCenterPage/>}/>}/>
          <Route path="/reach-us" element={<ReachUsPage/>}/>
          <Route path="/about" element={<AboutPage/>}/>
          <Route path="/careers" element={<CareersPage/>}/>
          <Route path="*" element={<NotFound/>}/>
        </Routes>
      </main>

      <footer className="footer">
        <div className="container" style={{display:'flex',justifyContent:'space-between',gap:16,flexWrap:'wrap'}}>
          <div>
            <div style={{fontWeight:600}}>Best Deal Forex Private Limited</div>
            <div>Hyderabad • Telangana, India</div>
          </div>
          <div style={{display:'flex',gap:16,flexWrap:'wrap',alignItems:'center'}}>
            <a href={`tel:${CONTACT_TEL}`}><Phone size={16}/> {CONTACT_PHONE}</a>
            <a href={`mailto:${CONTACT_EMAIL}`}><Mail size={16}/> {CONTACT_EMAIL}</a>
            <Link to="/terms" style={{textDecoration:'none'}}>Terms &amp; Conditions</Link>
            <Link to="/privacy" style={{textDecoration:'none'}}>Privacy Policy</Link>
          </div>
        </div>
      </footer>
    </div>
  )
}

/* ---------------- Home ---------------- */
function HomePage() {
  return (
    <section className="container">
      {/* Hero */}
      <div className="card" style={{ overflow: 'hidden' }}>
        <h1 style={{ marginBottom: 4 }}>Better Rates. Faster Service. Zero Hassle.</h1>
        <p className="small">Your trusted partner for foreign Currency Exchange
Traveling abroad or sending money overseas? Exchange 25+ currencies quickly, securely, and at the best rates—your smooth gateway to global transactions.</p>
        <p className="small" style={{ marginTop: 6, fontWeight: 600 }}>“Lots of Money for your Money”</p>

        <div style={{ display: 'flex', gap: 12, marginTop: 14, flexWrap: 'wrap' }}>
          <Link to="/reach-us" className="btn"><MessageCircle size={16}/> Get a Quote</Link>
          <Link to="/services" className="btn"><Boxes size={16}/> Our Services</Link>
          <a href="https://www.xe.com/currencyconverter/convert/?Amount=1&From=USD&To=INR" target="_blank" rel="noreferrer" className="btn secondary"><IndianRupee size={16}/> Forex Rates</a>
        </div>

        {/* Trust badges */}
        <div style={{ display: 'flex', gap: 16, marginTop: 16, flexWrap: 'wrap' }} className="small">
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}><Shield size={16}/> RBI authorised (FFMC licence FE.HY.FFMC/127/2014-15)</span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}><Clock size={16}/> Same-day service*</span>
        </div>
      </div>

                        {/* Features */}
      <div className="grid grid-2" style={{ marginTop: 16 }}>
        <FeatureCard icon={<Globe2 size={18}/>} title="Currency Exchange" desc="Traveling abroad or sending money overseas? Exchange 25+ currencies quickly, securely, and at the best rates—your smooth gateway to global transactions." />
        <FeatureCard icon={<CreditCard size={18}/>} title="Travel Cards" desc="Carry foreign currency the smart way. Reloadable prepaid travel cards with locked-in exchange rates, 24x7 access, and protection against fluctuations." />
        <FeatureCard icon={<Send size={18}/>} title="Send Money Abroad" desc="Quick, secure transfers for tuition, medical, travel, or family support—compliant, reliable, and at the best rates." />
        <FeatureCard icon={<CheckCircle2 size={18}/>} title="Doorstep Service" desc="Foreign exchange made effortless—currency, travel cards, or remittance services delivered safely to your doorstep." />
      </div>
    </section>
  )
}

/* ---------------- Services ---------------- */


function ServicesPage(){
  const services = [
    {title:"Foreign Exchange 💱", text:"Get the best value for your money with trusted currency exchange services. Quick, secure, and transparent—making your international travel and business easier than ever."},
    {title:"Remittances 🌍", text:"Send money abroad for tuition, living expenses, medical needs, or family support. Swift transfers with full RBI compliance ensure peace of mind every time."},
    {title:"Money Transfer 💸", text:"Experience instant, safe, and reliable money transfers across the globe. Whether for business or personal needs, we make sending and receiving money seamless."},
    {title:"Order Online 🖥️", text:"Forex and travel services at your fingertips! Order currency, travel cards, or remittance services online—convenient, fast, and delivered right to your door."},
    {title:"Travel Insurance 🛡️", text:"Stay covered on every journey. From medical emergencies to lost baggage, our comprehensive travel insurance gives you peace of mind wherever you go."},
    {title:"Travel & VISA Services ✈️", text:"Your one-stop solution for hassle-free travel. From visa assistance to ticketing and trip planning, we make your international journey smooth and stress-free."},
  ];
  return (
    <section className="container">
      <h2>Services</h2>
      <p className="small" style={{marginBottom:10}}>Complete forex and travel solutions to make your global journey easier.</p>
      <div className="grid grid-2" style={{gap:20}}>
        {services.map((s,i)=>(
          <div key={i} className="card" style={{padding:18}}>
            <div style={{fontWeight:600, marginBottom:8}}>{s.title}</div>
            <p className="small" style={{color:'#475569'}}>{s.text}</p>
          </div>
        ))}
      </div>
    </section>
  )
}



/* ---------------- Products ---------------- */
function ProductsPage() {
  const products = [
    {title:"Multi-Currency Travel Card", desc:"Chip & PIN, reloadable, worldwide acceptance.", bullets:["Low FX mark-up","ATM withdrawals","24×7 support"]},
    {title:"FX Cash Bundles", desc:"Curated currency notes for short trips.", bullets:["USD/EUR/GBP/AUD","Doorstep delivery","Instant invoice"]},
    {title:"Student Remittance Pack", desc:"End-to-end support for university payments.", bullets:["Tuition + GIC","Swift & compliant","Best rates"]},
  ];
  return (
    <section className="container">
      <h2>Products</h2>
      <p className="small" style={{marginBottom:10}}>Popular instruments for smooth international travel and remittances.</p>
      <div className="grid grid-3">
        {products.map((p,i)=>(
          <div key={i} className="card">
            <div style={{fontWeight:600}}>{p.title}</div>
            <p className="small" style={{marginTop:6}}>{p.desc}</p>
            <ul style={{margin:'10px 0 0 18px',color:'#475569'}}>
              {p.bullets.map((b,j)=><li key={j} style={{marginBottom:6}}>{b}</li>)}
            </ul>
          </div>
        ))}
      </div>
    </section>
  )
}

/* ---------------- Blog ---------------- */
function BlogPage() {
  return (
    <section className="container">
      <h2>Blog</h2>
      <p className="small">Articles and updates about foreign exchange, travel tips, and student finance.</p>
      <div className="grid" style={{marginTop:12}}>
        {[1,2,3].map(i=>(
          <article key={i} className="card">
            <div className="small">Coming soon</div>
            <div style={{fontWeight:600,marginTop:6}}>Sample Post {i}</div>
            <p className="small" style={{marginTop:6}}>We’ll publish fresh content here. Meanwhile, WhatsApp us for any queries.</p>
          </article>
        ))}
      </div>
    </section>
  )
}

/* ---------------- Knowledge ---------------- */
function KnowledgePage() {
  return (
    <section className="container">
      <h2>Knowledge</h2>
      <div className="grid" style={{marginTop:12}}>
        <FAQ q="How much foreign currency can I carry when travelling from India?" a="As per RBI/FEMA, travellers can carry forex within permitted limits; amounts vary by purpose and destination. Contact us for your case." />
        <FAQ q="What documents are needed for education remittance?" a="Passport, PAN, admission letter/fee invoice, and as applicable—Form A2 and purpose codes. We’ll guide you end-to-end." />
        <FAQ q="Do you offer doorstep KYC pickup?" a="Yes. We can arrange secure pickup and delivery within city limits." />
      </div>
    </section>
  )
}

/* ---------------- Reach Us ---------------- */
function ReachUsPage(){
  const [submitted, setSubmitted] = useState(false);
  const onSubmit = (e)=>{e.preventDefault(); setSubmitted(true);};
  return (
    <section className="container">
      <h2>Reach Us</h2>
      <div className="grid grid-2" style={{marginTop:12}}>
        <div className="card">
          <p className="small"><strong>Address:</strong><br/>15-31-2M-16/6, Flat No 6, Phase III, JNTU Road, Kukatpally Housing Board, Hyderabad, Telangana 500085</p>
          <p className="small" style={{marginTop:8}}><Phone size={16}/> <a href={`tel:${CONTACT_TEL}`}>{CONTACT_PHONE}</a></p>
          <p className="small" style={{marginTop:4}}><Mail size={16}/> <a href={`mailto:${CONTACT_EMAIL}`}>{CONTACT_EMAIL}</a></p>
          <div className="card" style={{marginTop:12,padding:0,overflow:'hidden'}}>
            <iframe
              title="BDFX Map"
              width="100%"
              height="260"
              style={{border:0}}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15227.756932009811!2d78.3860342!3d17.4858479!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb918eba8909db%3A0xfc65acbb4f8b6011!2sBest%20Deal%20Forex%20Private%20Limited!5e0!3m2!1sen!2sin!4v1690000000000!5m2!1sen!2sin">
            </iframe>
          </div>
        </div>
        <div className="card">
          <h3 style={{marginTop:0}}>Request a quote</h3>
          {submitted ? (
            <div className="card" style={{background:'#ecfeff',borderColor:'#bae6fd'}}>Thanks! We’ll contact you shortly.</div>
          ) : (
            <form onSubmit={onSubmit} className="grid" style={{gap:12}}>
              <div className="grid grid-2" style={{gap:12}}>
                <div><label>Name</label><input required placeholder="Your full name"/></div>
                <div><label>Email</label><input type="email" required placeholder="you@example.com"/></div>
              </div>
              <div className="grid grid-2" style={{gap:12}}>
                <div><label>Phone / WhatsApp</label><input placeholder="+91 9XXXXXXXXX"/></div>
                <div><label>Purpose</label><select><option>Foreign Exchange</option><option>Travel Card</option><option>Remittance</option><option>Other</option></select></div>
              </div>
              <div className="grid grid-2" style={{gap:12}}>
                <div><label>Currency</label><input placeholder="USD / EUR / GBP"/></div>
                <div><label>Amount</label><input placeholder="e.g., 1500"/></div>
              </div>
              <div><label>Message</label><textarea rows="3" placeholder="Anything else we should know?"></textarea></div>
              <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                <span className="small">By submitting, you agree to be contacted about your request.</span>
                <button className="btn" type="submit">Submit</button>
              </div>
            </form>
          )}
        </div>
      </div>
    </section>
  )
}

/* ---------------- About ---------------- */
function AboutPage(){
  return (
    <div>

    <section className="container">
      <h2>About Us</h2>

      <div className="card" style={{padding:20}}>
        <h3>Who We Are</h3>
        <p className="small">
          <strong>Best Deal Forex Private Limited (BDFX)</strong> is an entity authorized by the <strong>Reserve Bank of India (RBI)</strong> to buy and sell foreign currencies and prepaid travel cards. Built on a strong value system and managed by seasoned professionals with over <strong>20 years of industry experience</strong>, BDFX is committed to providing trusted and compliant forex solutions.
        </p>

        <h3>Our People</h3>
        <p className="small">
          Our employees are <strong>well‑trained, ethically driven, and customer‑focused</strong>. They bring passion to their work, are transparent in their communication, and are committed to delivering quality service. Every team member understands the importance of matching customer requirements with the right products and goes beyond the expected scope to serve better.
        </p>

        <h3>Our Business Model</h3>
        <p className="small">
          At BDFX, we believe in a <strong>customer‑first approach</strong>:
        </p>
        <ul className="small" style={{marginLeft:18}}>
          <li>We aim to reduce your costs and risks while offering tailored forex products.</li>
          <li>Our motto: <em>“We don’t do new things, but we always do things newly.”</em></li>
          <li>Services delivered <strong>at your doorstep</strong>, at your convenience, at competitive prices.</li>
        </ul>

        <h3>Board of Directors</h3>
        <ul className="small" style={{marginLeft:18}}>
          <li><strong>Mr. Viswanadhula Arun Kumar</strong></li>
          <li><strong>Ms. Viswanadhula Induvalli</strong></li>
        </ul>

        <h3>Key People</h3>
        <p className="small">
          <strong>Mr. Viswanadhula Arun Kumar</strong> is a dynamic professional with over <strong>25 years of expertise</strong> in:
        </p>
        <ul className="small" style={{marginLeft:18}}>
          <li>RBI Compliances &amp; FEMA Regulations</li>
          <li>Branch Operations &amp; Customer Relationship Management</li>
          <li>Forex Operations (retail and institutional)</li>
          <li>Business Development &amp; Branch Setup</li>
          <li>Team Management &amp; Sales Strategy</li>
        </ul>
        <p className="small">
          He has contributed across leading money changers including <strong>Pheroze Framroze &amp; Co. Pvt. Ltd.</strong>, <strong>Green Channel Travel Services (Div. of IRM Ltd.)</strong>, and <strong>Nium Forex Services India Pvt. Ltd.</strong> since 1999, holding diverse leadership roles.
        </p>
      </div>
    </section>

    </div>
  )
}



/* ---------------- Not Found ---------------- */
function NotFound(){ return <div className="container" style={{padding:40}}>Page not found</div>; }

/* ---------------- Small components ---------------- */
function FeatureCard({ icon, title, desc }) {
  return (
    <div className="card">
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontWeight: 600 }}>
        <span style={{ display: 'grid', placeItems: 'center', width: 36, height: 36, border: '1px solid #e2e8f0', borderRadius: 12 }}>
          {icon}
        </span>
        {title}
      </div>
      <p className="small" style={{ marginTop: 8 }}>{desc}</p>
    </div>
  );
}

function FAQ({ q, a }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="card">
      <button style={{background:'transparent',border:0,padding:0,fontWeight:600}} onClick={()=>setOpen(!open)}>{q}</button>
      {open && <p className="small" style={{marginTop:8}}>{a}</p>}
    </div>
  );
}